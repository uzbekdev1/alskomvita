interface JQuery {
   owlCarousel(options?: any, callback?: Function) : any;
}